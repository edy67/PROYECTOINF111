package leero;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Leer class.
 * This class provides methods to read different types of data.
 * 
 * @version 1.0
 */

public class Leer {
public static String dato ()
{ String cadena = "";
try
{ //Otra alternativapara declarar la Entrada de Datos
  BufferedReader Entrada=new BufferedReader(new
  InputStreamReader (System.in));
  cadena=Entrada.readLine();
}
catch (IOException e)
{ System.err.println ("Error : " + e.getMessage ());
}
return cadena;
}

public static short datoShort ()
{ try
  { return Short.parseShort (dato ());
  }
  catch (NumberFormatException e)
  {return Short.MIN_VALUE;
  }
}

public static int datoInt ()
{ try
  {return Integer.parseInt (dato ());
  }
  catch (NumberFormatException e)
  { return Integer.MIN_VALUE;
  }
}

public static long datoLong ()
{ try
  { return Long.parseLong (dato ());
  }
  catch (NumberFormatException e)
  { return Long.MIN_VALUE;
  }
}
public static float datoFloat()
{ try
  { Float f=Float.valueOf(dato());
    return f;
  }
  catch(NumberFormatException e)
  { return Float.NaN;
  }
}
public static double datoDouble()
{ try
  { Double d=Double.valueOf(dato());
    return d;
  }
  catch(NumberFormatException e)
  { return Double.NaN;
  }
 }
}