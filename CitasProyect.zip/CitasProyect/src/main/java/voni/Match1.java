
package voni;

import leero.Leer;

public class Match1
{
    private String paj;
    private UsuarioH ush[]= new UsuarioH[20];
    private UsuarioM usm[]= new UsuarioM[20];
    
    public Match1()
    {
        paj="pareja 1";
        ush[1] = new UsuarioH ("Mateo Campos Guzmán", 1998, "Riberalta", "Bolivia", "Soy un entusiasta de la tecnología y los videojuegos.\nDisfruto de la programación y el desarrollo de software. También me gusta el deporte y mantenerme en forma.", "Licenciatura", "Ingeniero en Sistemas", 0, "Ateo", "Español", "Bisexual");
        usm[1] = new UsuarioM();
    }
    
     public Match1(String a)
    {
        paj=a;
        ush[1] = new UsuarioH ("Mateo Campos Guzmán", 1998, "Riberalta", "Bolivia", "Soy un entusiasta de la tecnología y los videojuegos.\nDisfruto de la programación y el desarrollo de software. También me gusta el deporte y mantenerme en forma.", "Licenciatura", "Ingeniero en Sistemas", 0, "Ateo", "Español", "Bisexual");
        usm[1] = new UsuarioM();
    }

    public String getPaj()
    {
        return paj;
    }

    public UsuarioH[] getUsh()
    {
        return ush;
    }

    public UsuarioM[] getUsm()
    {
        return usm;
    }

    public void setPaj(String paj)
    {
        this.paj = paj;
    }
    
    public void leer()
    {
        System.out.println("");
        paj = Leer.dato();
    }
    public void mostrar()
    {
        System.out.println("numero de la pareja"+paj);
    }
    
    public void compatibles()
    {
        if(this.usm == this.usm)
        {
            System.out.println("son compatibles");
        }
        
        else
        {
            System.out.println("no son compatibles");
        }
    }
}