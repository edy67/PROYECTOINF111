
package voni;

public class MainCitas {

    public static void main(String[] args)
    {
        System.out.println("✨✨✨");
        
        Usuario usua = new Usuario();
        usua.leeru();
        usua.mostraru();
        Match m = new Match();
        m.match(usua);
        
    }
}