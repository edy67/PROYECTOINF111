
package voni;

public class MainCitas {

    public static void main(String[] args)
    {
        UsuarioH Andre = new UsuarioH();
        UsuarioH Mateo = new UsuarioH("Mateo Campos Guzmán", 1998, "Riberalta", "Bolivia", "Soy un entusiasta de la tecnología y los videojuegos.\nDisfruto de la programación y el desarrollo de software. También me gusta el deporte y mantenerme en forma.", "Licenciatura", "Ingeniero en Sistemas", 0, "Ateo", "Español", "Bisexual");
        UsuarioH Leo = new UsuarioH("Leonardo Vásquez Mendoza", 1997, "Cobija", "Bolivia", "Me considero una persona tranquila y reflexiva. \nDisfruto de la lectura y el aprendizaje constante. También me gusta pasar tiempo al aire libre y disfrutar de la naturaleza.", "Maestría", "Profesor de Filosofía", 0, "Budista", "Español", "Heterosexual");
        UsuarioH Camilo = new UsuarioH("Camilo Villarroel Coria", 1996, "Trinidad", "Bolivia", "Soy un apasionado de la cocina y la gastronomía.\nDisfruto de explorar nuevos sabores y culturas culinarias. También me gusta la jardinería y el cultivo de plantas.", "Licenciatura", "Chef", 0, "Católico", "Español", "Homosexual");
        UsuarioH Dani = new UsuarioH("Daniel Martínez Quiroga", 1998, "Oruro", "Bolivia", "Soy un amante del deporte y la vida saludable.\nDisfruto de la práctica de fútbol y el running. También me gusta leer y aprender cosas nuevas.", "Bachillerato", "Entrenador Deportivo", 0, "Protestante", "Español", "Bisexual");
        UsuarioH Benja = new UsuarioH("Benjamín Álvarez Flores", 2002, "La Paz", "Bolivia", "Me considero una persona amable y divertida.\nDisfruto de los deportes al aire libre y pasar tiempo con amigos.", "Bachillerato", "Estudiante", 0, "Católico", "Español", "Heterosexual");
        Andre.mostrar();
        Mateo.mostrar();
        Leo.mostrar(); 
        Camilo.mostrar();
        Dani.mostrar();
        Benja.mostrar();
        
        System.out.println("✨✨✨");
        
        
    }
}