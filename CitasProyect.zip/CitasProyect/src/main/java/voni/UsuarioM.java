
package voni;

public class UsuarioM extends Usuario
{
    protected String genero = "Mujer";
    protected String orientasexual;
    
    public UsuarioM()
    {
        super.nomb = "Olinda Mamani Pinto";
        super.añonac = 2002;
        super.ciudad = "La Paz";
        super.pais = "Bolivia";
        super.descper = """
                        Soy un chicoa normal, me gusta el fútbol, \
                        me apasiona la lectura y la medicina. \n\
                        Siempre estoy dispuesta a tener una buena plática \
                        podría hablar tranquilamente por horas sobre cualquier tema.""";
        super.niveledu = "Bachillerato";
        super.profesi = "Estudiante";
        super.hijos = 0;
        super.reli = "Católico";
        super.idioma = "Español";
        orientasexual = "Heterosexual";
        genero = "Hombre";
        
    }
    
    public void setGenero(String a) {
        genero = a;
    }

    public void setOrientasexu(String a) {
        orientasexual = a;
    }

    public String getGenero() {
        return genero;
    }

    public String getOrientasexu() {
        return orientasexual;
    }
}
