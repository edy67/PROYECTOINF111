
package voni;

import leero.Leer;

public class Usuario
{
    protected String nomb;
    protected int añonac;
    protected String ciudad;
    protected String pais;
    protected String descper;
    protected String niveledu;
    protected String profesi;
    protected int hijos;
    protected String reli;
    protected String idioma;

    public void setNomb(String a) {
        nomb = a;
    }

    public void setAñonac(int a) {
        añonac = a;
    }

    public void setCiudad(String a) {
        ciudad = a;
    }

    public void setPais(String a) {
        pais = a;
    }

    public void setDescper(String a) {
        descper = a;
    }

    public void setNiveledu(String a) {
        niveledu = a;
    }

    public void setProfesi(String a) {
        profesi = a;
    }

    public void setHijos(int a) {
        hijos = a;
    }

    public void setReli(String a) {
        reli = a;
    }

    public void setIdioma(String a) {
        idioma = a;
    }

    public String getNomb() {
        return nomb;
    }

    public int getAñonac() {
        return añonac;
    }

    public String getCiudad() {
        return ciudad;
    }

    public String getPais() {
        return pais;
    }

    public String getDescper() {
        return descper;
    }

    public String getNiveledu() {
        return niveledu;
    }

    public String getProfesi() {
        return profesi;
    }

    public int getHijos() {
        return hijos;
    }

    public String getReli() {
        return reli;
    }

    public String getIdioma() {
        return idioma;
    }
}
