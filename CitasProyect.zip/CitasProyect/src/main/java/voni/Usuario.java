
package voni;

import leero.Leer;

public class Usuario
{
    protected String nomb;
    protected int añonac;
    protected String ciud;
    protected String pai;
    protected String descper;
    protected String niveledu;
    protected String profesi;
    protected int hijo;
    protected String reli;
    protected String idiom;
    protected String orientasexual;
    protected String gener;
    
    public Usuario() {}
    
    public Usuario(String nombr, int añonaci, String ciudad, String pais, String descpers, String niveleduc, String profesio, int hijos, String relig, String idioma, String orientasex, String genero)
    {
        nomb = nombr;
        añonac = añonaci;
        ciud = ciudad;
        pai = pais;
        descper = descpers;
        niveledu = niveleduc;
        profesi = profesio;
        hijo = hijos;
        reli = relig;
        idiom = idioma;
        orientasexual = orientasex;
        gener = genero;
    }

    public String getNomb() {
        return nomb;
    }

    public void setNomb(String a) {
        nomb = a;
    }

    public int getAñonac() {
        return añonac;
    }

    public void setAñonac(int a) {
        añonac = a;
    }

    public String getCiud() {
        return ciud;
    }

    public void setCiud(String a) {
        ciud = a;
    }

    public String getPai() {
        return pai;
    }

    public void setPai(String a) {
        pai = a;
    }

    public String getDescper() {
        return descper;
    }

    public void setDescper(String a) {
        descper = a;
    }

    public String getNiveledu() {
        return niveledu;
    }

    public void setNiveledu(String a) {
        niveledu = a;
    }

    public String getProfesi() {
        return profesi;
    }

    public void setProfesi(String a) {
        profesi = a;
    }

    public int getHijo() {
        return hijo;
    }

    public void setHijo(int a) {
        hijo = a;
    }

    public String getReli() {
        return reli;
    }

    public void setReli(String a) {
        reli = a;
    }

    public String getIdiom() {
        return idiom;
    }

    public void setIdiom(String a) {
        idiom = a;
    }

    public String getOrientasexual() {
        return orientasexual;
    }

    public void setOrientasexual(String a) {
        orientasexual = a;
    }

    public String getGener() {
        return gener;
    }

    public void setGener(String a) {
        gener = a;
    }
    
    public void leeru()
    {
        System.out.println("Ingrese su nombre");
        nomb = Leer.dato();
        System.out.println("Ingrese su añonac");
        añonac = Leer.datoInt();
        System.out.println("Ingrese su ciudad");
        ciud = Leer.dato();
        System.out.println("Ingrese su pais");
        pai = Leer.dato();
        System.out.println("Ingrese su descper");
        descper = Leer.dato();
        System.out.println("Ingrese su niveledu");
        niveledu = Leer.dato();
        System.out.println("Ingrese su profesi");
        profesi = Leer.dato();
        System.out.println("Ingrese su numhijos");
        hijo = Leer.datoInt();
        System.out.println("Ingrese su reli");
        reli = Leer.dato();
        System.out.println("Ingrese su idioma");
        idiom = Leer.dato();
        System.out.println("Ingrese su orientasexual");
        orientasexual = Leer.dato();
        System.out.println("Ingrese su genero");
        gener = Leer.dato();
    }
    
        public void mostraru()
    {
        System.out.println("---- DATOS USUARIO ----");
        System.out.println("nombre: " + nomb);
        System.out.println("añonac: " + añonac);
        System.out.println("ciudad: " + ciud);
        System.out.println("pais: " + pai);
        System.out.println("descper: " + descper);
        System.out.println("niveledu: " + niveledu);
        System.out.println("profesi: " + profesi);
        System.out.println("numhijos: " + hijo);
        System.out.println("reli: " + reli);
        System.out.println("idioma: " + idiom);
        System.out.println("orientasexual: " + orientasexual);
        System.out.println("genero: " + gener);
    }    

}
