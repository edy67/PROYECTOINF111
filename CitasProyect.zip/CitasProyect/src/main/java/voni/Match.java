
package voni;

public class Match
{
    private int cdp = 6;
    private int scdph = 0;
    private int scdpm = 0;
    private int cdh = 0;
    private int cdm = 0;
    private UsuarioH usuh[] = new UsuarioH[20];
    private UsuarioM usum[] = new UsuarioM[20];
    private int[] usumcoinci = new int[10];
    private int[] usuhcoinci = new int[10]; 
    
    public Match()
    {
        usuh[1] = new UsuarioH();
        usuh[2] = new UsuarioH("Mateo Campos Guzmán", 1998, "Potosí", "Bolivia", "Soy un entusiasta de la tecnología y los videojuegos.\nDisfruto de la programación y el desarrollo de software. También me gusta el deporte y mantenerme en forma.", "Licenciatura", "Ingeniero(a)", 0, "Atesmo", "Español", "Bisexual");
        usuh[3] = new UsuarioH("Leonardo Vásquez Mendoza", 1997, "Chuquisaca", "Bolivia", "Me considero una persona tranquila y reflexiva. \nDisfruto de la lectura y el aprendizaje constante. También me gusta pasar tiempo al aire libre y disfrutar de la naturaleza.", "Maestría", "Psicólogo(a)", 1, "Judaísmo", "Español", "Heterosexual");
        usuh[4] = new UsuarioH("Camilo Villarroel Coria", 1995, "Cochabamba", "Bolivia", "Soy un apasionado de la cocina y la gastronomía.\nDisfruto de explorar nuevos sabores y culturas culinarias. También me gusta la jardinería y el cultivo de plantas.", "Licenciatura", "Pastelero(a)", 0, "Budismo", "Español", "Homosexual");
        usuh[5] = new UsuarioH("Daniel Martínez Quiroga", 1998, "Oruro", "Bolivia", "Soy un amante del deporte y la vida saludable.\nDisfruto de la práctica de fútbol y el running. También me gusta leer y aprender cosas nuevas.", "Bachillerato", "Entrenador(a)", 0, "Protestante", "Español", "Bisexual");
        usuh[6] = new UsuarioH("Benjamín Álvarez Flores", 2002, "La Paz", "Bolivia", "Me considero una persona amable y divertida.\nDisfruto de los deportes al aire libre y pasar tiempo con amigos.", "Bachillerato", "Estudiante", 1, "Catolicismo", "Español", "Heterosexual");
        usum[1] = new UsuarioM();
        usum[2] = new UsuarioM("Valeria Rojas Villanueva", 1999, "Tarija", "Bolivia", "Me apasiona la tecnología y el diseño gráfico.\nDisfruto creando contenido digital y explorando nuevas tendencias. También me gusta hacer ejercicio y cuidar mi salud.", "Licenciatura", "Informático(a)", 0, "Ateísmo", "Español", "Bisexual");
        usum[3] = new UsuarioM("Sofía Terrazas Miranda", 1996, "Santa Cruz", "Bolivia", "Soy una persona tranquila y soñadora.\nMe encanta sumergirme en un buen libro y descubrir nuevos mundos. También disfruto de la naturaleza y el aire libre.", "Maestría", "Profesor(a)", 1, "Evangelismo", "Español", "Heterosexual");
        usum[4] = new UsuarioM("Zoe Morales Torrez", 1998, "Beni", "Bolivia", "Mi pasión es la repostería y la cocina saludable.\nMe fascina experimentar con nuevos ingredientes y crear delicias culinarias. También disfruto del yoga y la meditación.", "Licenciatura", "Chef", 0, "Islamismo", "Español", "Homosexual");
        usum[5] = new UsuarioM("María Carvajal Pinto", 1997, "Oruro", "Bolivia", "Soy una apasionada del fitness y los deportes de aventura.\nMe encanta practicar escalada y correr al aire libre. También disfruto de aprender idiomas y culturas nuevas.", "Bachillerato", "Médico(a)", 0, "Protestante", "Español", "Bisexual");
        usum[6] = new UsuarioM("Rosa Quispe Mamani", 2003, "Pando", "Bolivia", "Me considero una persona alegre y sociable.\nDisfruto de pasar tiempo con amigos, bailar y escuchar música. También me gusta el arte y la pintura.", "Bachillerato", "Estudiante", 0, "Cristianismo", "Español", "Heterosexual");
    }
    
    public void match(Usuario A)
    {
        int i, d;
        
        for(i = 1; i <= cdp; i++)
        {
            if(A.getGener().compareTo("Hombre") == 0)
            {
                if(A.getOrientasexual().compareTo("Heterosexual") == 0)
                {
                    if(A.getOrientasexual().compareTo(usum[i].getorientasexual()) == 0)
                    {
                        scdpm = (scdpm * 10) + i;
                    }
                }
                if(A.getOrientasexual().compareTo("Homosexual") == 0)
                {
                    if(A.getOrientasexual().compareTo(usuh[i].getorientasexual()) == 0)
                    {
                        scdph = (scdph * 10) + i;
                    }
                }
                if(A.getOrientasexual().compareTo("Bisexual") == 0)
                {
                    if(A.getOrientasexual().compareTo(usuh[i].getorientasexual()) == 0)
                    {
                        scdph = (scdph * 10) + i;
                    }
                    if(A.getOrientasexual().compareTo(usum[i].getorientasexual()) == 0)
                    {
                        scdpm = (scdpm * 10) + i;
                    }
                }
            }
            else
            {
                if(A.getOrientasexual().compareTo("Heterosexual") == 0)
                {
                    if(A.getOrientasexual().compareTo(usuh[i].getorientasexual()) == 0)
                    {
                        scdph = (scdph * 10) + i;
                    }
                }
                if(A.getOrientasexual().compareTo("Homosexual") == 0)
                {
                    if(A.getOrientasexual().compareTo(usum[i].getorientasexual()) == 0)
                    {
                        scdpm = (scdpm * 10) + i;
                    }
                }
                if(A.getOrientasexual().compareTo("Bisexual") == 0)
                {
                    if(A.getOrientasexual().compareTo(usuh[i].getorientasexual()) == 0)
                    {
                        scdph = (scdph * 10) + i;
                    }
                    if(A.getOrientasexual().compareTo(usum[i].getorientasexual()) == 0)
                    {
                        scdpm = (scdpm * 10) + i;
                    }
                }
            }
        }
        
        if(scdph > 0)
        {
            cdh = (int) (Math.log10(scdph) + 1);
        }
        
        if(scdpm > 0)
        {
            cdm = (int) (Math.log10(scdpm) + 1);
        }
       
        System.out.println("Cantidad de parejas hombres: " + cdh);
        System.out.println("Cantidad de parejas mujeres: " + cdm);
        
        if(cdm > 0 && cdh > 0)
        {
            for(i = 1; i <= cdm; i++)
            {
                d = scdpm % 10;
                scdpm = scdpm / 10;
                if(A.getCiud().compareTo(usum[d].getciudadd()) == 0)
                {
                    usumcoinci[d] = usumcoinci[d] + 1;
                }
                if(A.getPai().compareTo(usum[d].getpaiss()) == 0)
                {
                    usumcoinci[d] = usumcoinci[d] + 1;
                }
                if(A.getNiveledu().compareTo(usum[d].getniveleduc()) == 0)
                {
                    usumcoinci[d] = usumcoinci[d] + 1;
                }
                if(A.getProfesi().compareTo(usum[d].getprofesio()) == 0)
                {
                    usumcoinci[d] = usumcoinci[d] + 1;
                }
                if(A.getReli().compareTo(usum[d].getrelig()) == 0)
                {
                    usumcoinci[d] = usumcoinci[d] + 1;
                }
                if(A.getIdiom().compareTo(usum[d].getidiomaa()) == 0)
                {
                    usumcoinci[d] = usumcoinci[d] + 1;
                }
            }
            
            for(i = 1; i <= cdh; i++)
            {
                d = scdph % 10;
                scdph = scdph / 10;
                if(A.getCiud().compareTo(usuh[d].getciudadd()) == 0)
                {
                    usuhcoinci[d] = usuhcoinci[d] + 1;
                }
                if(A.getPai().compareTo(usuh[d].getpaiss()) == 0)
                {
                    usuhcoinci[d] = usuhcoinci[d] + 1;
                }
                if(A.getNiveledu().compareTo(usuh[d].getniveleduc()) == 0)
                {
                    usuhcoinci[d] = usuhcoinci[d] + 1;
                }
                if(A.getProfesi().compareTo(usuh[d].getprofesio()) == 0)
                {
                    usuhcoinci[d] = usuhcoinci[d] + 1;
                }
                if(A.getReli().compareTo(usuh[d].getrelig()) == 0)
                {
                    usuhcoinci[d] = usuhcoinci[d] + 1;
                }
                if(A.getIdiom().compareTo(usuh[d].getidiomaa()) == 0)
                {
                    usuhcoinci[d] = usuhcoinci[d] + 1;
                }
            }
        }
        
        else
        {
            if(cdm > 0)
            {
                for(i = 1; i <= cdm; i++)
                {
                    d = scdpm % 10;
                    scdpm = scdpm / 10;
                    if(A.getCiud().compareTo(usum[d].getciudadd()) == 0)
                    {
                        usumcoinci[d] = usumcoinci[d] + 1;
                    }
                    if(A.getPai().compareTo(usum[d].getpaiss()) == 0)
                    {
                        usumcoinci[d] = usumcoinci[d] + 1;
                    }
                    if(A.getNiveledu().compareTo(usum[d].getniveleduc()) == 0)
                    {
                        usumcoinci[d] = usumcoinci[d] + 1;
                    }
                    if(A.getProfesi().compareTo(usum[d].getprofesio()) == 0)
                    {
                        usumcoinci[d] = usumcoinci[d] + 1;
                    }
                    if(A.getReli().compareTo(usum[d].getrelig()) == 0)
                    {
                        usumcoinci[d] = usumcoinci[d] + 1;
                    }
                    if(A.getIdiom().compareTo(usum[d].getidiomaa()) == 0)
                    {
                        usumcoinci[d] = usumcoinci[d] + 1;
                    }
                }
            }
            else
            {
                for(i = 1; i <= cdh; i++)
                {
                    d = scdph % 10;
                    scdph = scdph / 10;
                    if(A.getCiud().compareTo(usuh[d].getciudadd()) == 0)
                    {
                        usuhcoinci[d] = usuhcoinci[d] + 1;
                    }
                    if(A.getPai().compareTo(usuh[d].getpaiss()) == 0)
                    {
                        usuhcoinci[d] = usuhcoinci[d] + 1;
                    }
                    if(A.getNiveledu().compareTo(usuh[d].getniveleduc()) == 0)
                    {
                        usuhcoinci[d] = usuhcoinci[d] + 1;
                    }
                    if(A.getProfesi().compareTo(usuh[d].getprofesio()) == 0)
                    {
                        usuhcoinci[d] = usuhcoinci[d] + 1;
                    }
                    if(A.getReli().compareTo(usuh[d].getrelig()) == 0)
                    {
                        usuhcoinci[d] = usuhcoinci[d] + 1;
                    }
                    if(A.getIdiom().compareTo(usuh[d].getidiomaa()) == 0)
                    {
                        usuhcoinci[d] = usuhcoinci[d] + 1;
                    }
                }
            }
        }
    for (i = 1; i <= 6; i++)
    {
            if (usumcoinci[i] > 0)
            {
                System.out.println("Usuario: " + usum[i].getnombr() + " " + usumcoinci[i] + " coincidencias.");
                usum[i].mostrarm();
            }
            if (usuhcoinci[i] > 0)
            {
                System.out.println("Usuario: " + usuh[i].getnombr() + " " +  usuhcoinci[i] + " coincidencias.");
                usuh[i].mostrarh();
            }
        }
    }
}
