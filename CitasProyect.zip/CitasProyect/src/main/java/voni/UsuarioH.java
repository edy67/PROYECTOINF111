
package voni;

import leero.Leer;

public class UsuarioH extends Usuario
{
    protected String genero;
    protected String orientasexual;
    
    public UsuarioH()
    {
        super.nomb = "Andres Omar Sumi Guzman";
        super.añonac = 2005;
        super.ciud = "La Paz";
        super.pai = "Bolivia";
        super.descper = """
                        Soy un chico normal, me gustan los videojuegos, \
                        me apasiona la lectura y los temas interesantes. \n\
                        Siempre estoy dispuesto a tener una buena plática \
                        podría hablar tranquilamente por horas sobre cualquier tema.""";
        super.niveledu = "Bachillerato";
        super.profesi = "Técnico Medio Gastronomía";
        super.hijo = 0;
        super.reli = "Católico";
        super.idiom = "Español";
        orientasexual = "Heterosexual";
        genero = "Hombre";
    }
    
    public UsuarioH(String nomb, int añonac, String ciudad, String pais, String descper, String niveledu, String profesi, int hijos, String reli, String idioma, String orientasexu)
    {
        super.nomb = nomb;
        super.añonac = añonac;
        super.ciud = ciudad;
        super.pai = pais;
        super.descper = descper;
        super.niveledu = niveledu;
        super.profesi = profesi;
        super.hijo = hijos;
        super.reli = reli;
        super.idiom = idioma;
        orientasexual = orientasexu;
        genero = "Hombre";
    }

    public String getnombr() {
        return super.nomb;
    }

    public void setnombr(String a) {
        super.nomb = a;
    }

    public int getañonaci() {
        return super.añonac;
    }

    public void setañonaci(int a) {
        super.añonac = a;
    }

    public String getciudadd() {
        return super.ciud;
    }

    public void setciudadd(String a) {
        super.ciud = a;
    }

    public String getpaiss() {
        return super.pai;
    }

    public void setpaiss(String a) {
        super.pai = a;
    }

    public String getdescpers() {
        return super.descper;
    }

    public void setdescpers(String a) {
        super.descper = a;
    }

    public String getniveleduc() {
        return super.niveledu;
    }

    public void setniveleduc(String a) {
        super.niveledu = a;
    }

    public String getprofesio() {
        return super.profesi;
    }

    public void setprofesio(String a) {
        super.profesi = a;
    }

    public int gethijoss() {
        return super.hijo;
    }

    public void sethijoss(int a) {
        super.hijo = a;
    }

    public String getrelig() {
        return super.reli;
    }

    public void setrelig(String a) {
        super.reli = a;
    }

    public String getidiomaa() {
        return super.idiom;
    }

    public void setidiomaa(String a) {
        super.idiom = a;
    }

    public String getorientasexual() {
        return orientasexual;
    }

    public void setorientasexual(String a) {
        orientasexual = a;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String a) {
        genero = a;
    }
    
    public void leerh()
    {
        System.out.println("Ingrese su nombre");
        super.nomb = Leer.dato();
        System.out.println("Ingrese su añonac");
        super.añonac = Leer.datoInt();
        System.out.println("Ingrese su ciudad");
        super.ciud = Leer.dato();
        System.out.println("Ingrese su pais");
        super.pai = Leer.dato();
        System.out.println("Ingrese su descper");
        super.descper = Leer.dato();
        System.out.println("Ingrese su niveledu");
        super.niveledu = Leer.dato();
        System.out.println("Ingrese su profesi");
        super.profesi = Leer.dato();
        System.out.println("Ingrese su numhijos");
        super.hijo = Leer.datoInt();
        System.out.println("Ingrese su reli");
        super.reli = Leer.dato();
        System.out.println("Ingrese su idioma");
        super.idiom = Leer.dato();
        System.out.println("Ingrese su orientasexual");
        orientasexual = Leer.dato();
    }
    
        public void mostrarh()
    {
        System.out.println("---- DATOS USUARIO ----");
        System.out.println("nombre: " + nomb);
        System.out.println("añonac: " + añonac);
        System.out.println("ciudad: " + ciud);
        System.out.println("pais: " + pai);
        System.out.println("descper: " + descper);
        System.out.println("niveledu: " + niveledu);
        System.out.println("profesi: " + profesi);
        System.out.println("numhijos: " + hijo);
        System.out.println("reli: " + reli);
        System.out.println("idioma: " + idiom);
        System.out.println("orientasexual: " + orientasexual);
        System.out.println("genero: " + genero);
    }
}
