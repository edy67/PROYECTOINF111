
package voni;

import leero.Leer;

public class UsuarioH extends Usuario
{
    protected String genero;
    protected String orientasexual;
    
    public UsuarioH()
    {
        super.nomb = "Andres Omar Sumi Guzman";
        super.añonac = 2005;
        super.ciudad = "La Paz";
        super.pais = "Bolivia";
        super.descper = """
                        Soy un chico normal, me gustan los videojuegos, \
                        me apasiona la lectura y los temas interesantes. \n\
                        Siempre estoy dispuesto a tener una buena plática \
                        podría hablar tranquilamente por horas sobre cualquier tema.""";
        super.niveledu = "Bachillerato";
        super.profesi = "Técnico Medio Gastronomía";
        super.hijos = 0;
        super.reli = "Católico";
        super.idioma = "Español";
        orientasexual = "Heterosexual";
        genero = "Hombre";
    }
    
    public UsuarioH(String nomb, int añonac, String ciudad, String pais, String descper, String niveledu, String profesi, int hijos, String reli, String idioma, String orientasex)
    {
        super.nomb = nomb;
        super.añonac = añonac;
        super.ciudad = ciudad;
        super.pais = pais;
        super.descper = descper;
        super.niveledu = niveledu;
        super.profesi = profesi;
        super.hijos = hijos;
        super.reli = reli;
        super.idioma = idioma;
        orientasexual = orientasex;
        genero = "Hombre";
    }

    public void setGenero(String a) {
        genero = a;
    }

    public void setOrientasexu(String a) {
        orientasexual = a;
    }

    public String getGenero() {
        return genero;
    }

    public String getOrientasexu() {
        return orientasexual;
    }
    
    public void leer()
    {
        System.out.println("Ingrese su nombre");
        super.nomb = Leer.dato();
        System.out.println("Ingrese su añonac");
        super.añonac = Leer.datoInt();
        System.out.println("Ingrese su ciudad");
        super.ciudad = Leer.dato();
        System.out.println("Ingrese su pais");
        super.pais = Leer.dato();
        System.out.println("Ingrese su descper");
        super.descper = Leer.dato();
        System.out.println("Ingrese su niveledu");
        super.niveledu = Leer.dato();
        System.out.println("Ingrese su profesi");
        super.profesi = Leer.dato();
        System.out.println("Ingrese su numhijos");
        super.hijos = Leer.datoInt();
        System.out.println("Ingrese su reli");
        super.reli = Leer.dato();
        System.out.println("Ingrese su idioma");
        super.idioma = Leer.dato();
        System.out.println("Ingrese su orientasexual");
        orientasexual = Leer.dato();
    }
    
    public void mostrar()
    {
        System.out.println("---- DATOS USUARIO ----");
        System.out.println("nombre: " + nomb);
        System.out.println("añonac: " + añonac);
        System.out.println("ciudad: " + ciudad);
        System.out.println("pais: " + pais);
        System.out.println("descper: " + descper);
        System.out.println("niveledu: " + niveledu);
        System.out.println("profesi: " + profesi);
        System.out.println("numhijos: " + hijos);
        System.out.println("reli: " + reli);
        System.out.println("idioma: " + idioma);
        System.out.println("orientasexual: " + orientasexual);
        System.out.println("genero: " + genero);
    }
}
